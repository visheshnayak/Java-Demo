import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class DemoFW {
	public static void main(String [] args)
	{
		FileWriter writer = null;
		Scanner scanner = new Scanner(System.in);
		try {
			writer = new FileWriter("myfile.txt");
			System.out.println("Input: ");
			String input = scanner.nextLine();
			writer.write(input);
			writer.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
