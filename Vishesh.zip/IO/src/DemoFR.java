import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class DemoFR {
	public static void main(String[] args) {
		FileReader reader = null;
		try {
			reader = new FileReader("myfile.txt");
			byte b;
			do
			{
				b = (byte) reader.read();
				if (b != -1)
					System.out.println((char) b);
			}while( b!= -1);
			
		}catch (FileNotFoundException fe){
			fe.printStackTrace();			
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
