
public class Company {

	private String name, address, type;
	private int number;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	
	public Company(String n, String a, String t, int num)
	{
		this.name = n;
		this.address = a;
		this.type = t;
		this.number = num;
	}
	
	public void  show()
	{
		System.out.println(""+name+" "+address+" "+type+" "+number);
	}
	
	public static void main(String [] args)
	{
		Company com1, com2, com3;
		com1 = new Company("A", "B", "C", 1);
		com2 = new Company("D", "E", "F", 2);
		com3 = new Company("G", "H", "I", 3);
		
		com1.show();
		com2.show();
		com3.show();
		
		com2.setAddress("Andheri");
		com2.show();
	}
}
