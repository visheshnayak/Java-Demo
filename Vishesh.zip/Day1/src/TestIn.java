
public class TestIn {
	public static void main(String [] args)
	{
		Emp e1 = new Emp(1, 10000, "Vishesh");
		e1.show();
//		e1.setName("ABC");
	}

}
