
public class Class1 {
	
	public static void main(String[] args){
		int x =10;
		System.out.println("All or nothing, x = "+(x +20));
	}						
}

class Class2 {
	
	public static void main(String[] args){
		int x =10;
		System.out.println("All or nothing, x = "+(x +20));
	}						
} 