
public interface StuManable {
	public int total(Student student);
	public float percentage(Student student);
	public Student topper(Student[] student);
	public int highestMarks(Student[] student);
	public Student findByRollno(Student[] student, int rollNo);
	public Student[] findByName(Student[] student, String name);

}

class SM implements StuManable
{
	@Override
	public int total(Student student) {
		// TODO Auto-generated method stub
		int tot = 0;
		for(int i : student.getMarks())
		{
			tot += i;
		}
		student.settotal(tot);
		return tot;
	}
	
	@Override
	public float percentage(Student student) {
		// TODO Auto-generated method stub
		float perc;
		perc = student.gettotal()/5;
		student.setperc(perc);
		return perc;
		
	}
	
	@Override
	public Student topper(Student[] student) {
		// TODO Auto-generated method stub
		Student top = null;
		int high=0;
		for (Student i:student)
		{
			if (high<i.gettotal())
			{
				top = i;
			}
		}
		
		return top;
	}
	
	@Override
	public int highestMarks(Student[] student) {
		// TODO Auto-generated method stub
		int high=0;
		for (Student i:student)
		{
			if (high<i.gettotal())
			{
				high = i.gettotal();
			}
		}
		
		return high;
	}
	
	@Override
	public Student findByRollno(Student[] student, int rollNo) {
		// TODO Auto-generated method stub
		Student res = null;
		for(Student i: student)
		{
			if(rollNo==i.getRollno())
			{
				res = i;
			}
		}
		return res;
	}
	
	@Override
	public Student[] findByName(Student[] student, String name) {
		// TODO Auto-generated method stub
		
		Student s[] = null;
		int count=0;
		for(Student i:student)
		{
			if(name.equals(i.getName()))
			{
				count++;
			}
		}
		s = new Student[count];count =0;
		for(Student i: student)
		{
			if(name.equals(i.getName()))
			{
				s[count] = i;
				count++;
			}
		}
		
		
		return s;
	}
	
}