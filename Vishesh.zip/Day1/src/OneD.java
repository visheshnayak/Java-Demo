
public class OneD {
	
	public static void main(String[] args)
	{
//		int [] arr = new int [5];
//		for ( int i = 0; i < arr.length; i++ )
//		{
//			arr[i] = i;
//			//System.out.println(arr[i]);
//		}
//		
//		for(int i: arr)
//		{
//			System.out.println(i);
//		}
		
		int [][] ar = new int[3][];
		ar[0] = new int [3];
		ar[1] = new int [2];
		ar[2] = new int [7];
		for(int i = 0; i<ar.length; i++)
		{
			for(int j=0; j<ar[i].length; j++)
			{
				ar[i][j] = j;
				System.out.print(ar[i][j]);
			}
			System.out.println();
		}
		
		for(int[] a : ar)
		{
			for(int i:a)
			{
				System.out.print(i+" ");
			}
			System.out.println();
		}
	}

}
