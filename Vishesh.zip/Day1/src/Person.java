
public class Person {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Person()
	{
		name = "XYZ";
	}

	
	public Person(String name)
	{
		this.name = name;
	}
	
	public void show()
	{
		System.out.println(name);
	}
	
	public String toString()
	{
		return name;
	}
	
	@Override
	public boolean equals(Object object) {
		// TODO Auto-generated method stub
		Person person = (Person) object;
		return this.name.equals(person.name);
	}
	
}
