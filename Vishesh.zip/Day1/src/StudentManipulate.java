
public class StudentManipulate {
	
	public Student showStudent(Student student)
	{
		Student student2 =null;
		student2 = student;
		return student2;
	}
	
	public int calculateTotal(Student student)
	{
		int total = 0;
		for(int i: student.getMarks())
		{
			total += i;
		}
		student.settotal(total);
		return total;
	}
	
	public float calculatePercentage(Student student)
	{
		float percentage = 0f;
		percentage = ( student.gettotal()/500f)*100;
		student.setperc(percentage);
		return percentage;
		
	}

}
