
public class TestStudent1 {
	public static void main(String[] args){
		Student s1 = new Student(10, "ABC", 20, 20, 20);
		StudentManipulate sm = new StudentManipulate();
		Student s = sm.showStudent(s1);
		
		System.out.println(s.getName() +" "+ s.getRollno());
		System.out.println("Percentage: "+sm.calculatePercentage(s1)+"\nTotal: "+sm.calculateTotal(s1));
	}

}
