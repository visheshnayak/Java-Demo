
public class EmpMan {
	
	public Employee showEmp(Employee emp)
	{
		Employee emp1 = null;
		emp1 = emp;
		return emp1;
	}
	
	public float calcGS(Employee emp)
	{
		float gs = 0f;
		
		if ( emp.getB_salary() <= 10000 )
		{
			gs = emp.getB_salary() + 0.25f*emp.getB_salary();
		}
		
		else if ( emp.getB_salary() > 10000 && emp.getB_salary() <= 15000)
			{
				gs = emp.getB_salary() + 0.5f*emp.getB_salary();
			}
		else 
		{
			gs = emp.getB_salary() + 0.75f*emp.getB_salary();
		}
		
		emp.setG_salary(gs);
		return gs;
	}

}
