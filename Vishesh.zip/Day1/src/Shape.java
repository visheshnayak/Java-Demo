
public abstract class Shape {
	abstract public void calculateArea();
	
	public static void main(String[] args)
	{
//		Shape shape = new Shape();
		
	}

}

class MyShape extends Shape
{

	@Override
	public void calculateArea() {
		// TODO Auto-generated method stub
		
	}
	
}