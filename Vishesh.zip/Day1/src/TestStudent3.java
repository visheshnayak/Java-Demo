import java.util.Scanner;

public class TestStudent3 {
	public static void main(String []args){
		
		Scanner sc = new  Scanner(System.in);
		
		int[] m =new int [5];
		
		String name;
		int rollno, std;
				
		Student [] stud =new Student[5];
		
		for ( int i = 0; i<stud.length ; i++)
		{
			System.out.println("Input: ");
			System.out.println("Name: ");
			name = sc.nextLine();
			System.out.println("RollNo: ");
			rollno = sc.nextInt();
			System.out.println("Standard: ");
			std = sc.nextInt();
			System.out.println("Marks: ");
			for(int k: m)
			{
				k = sc.nextInt();
			}
			stud[i] =new Student(rollno, std, name, m);
		}
		
		SM sm = new SM();
		
		for (int i=0; i<stud.length; i++)
		{
			System.out.println(stud[i].getName() + " " +
						sm.total(stud[i]) +" "+ sm.percentage(stud[i])+" ");
		}
		
		System.out.println("Topper: " +sm.topper(stud));
		System.out.println("Highest Marks: "+sm.highestMarks(stud));
		System.out.println(sm.findByRollno(stud,  2));
		
//		for(Student i: sm.findByName(stud, "A1"))
//		{
//			System.out.println("L");
//		}
		
		Student[] s9 = sm.findByName(stud, "A1");
		
		for(int i = 0; i< s9.length; i++)
		{
			System.out.println(s9[i]);
		}
		
	}
}
