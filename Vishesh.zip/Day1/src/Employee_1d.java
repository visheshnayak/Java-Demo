
public class Employee_1d {
	public static void main(String[] args)
	{
		Employee[] employees = new Employee[3];
		employees[0] = new Employee("Vishesh", 1, 10000);
		employees[1] = new Employee("Kumar", 2, 15000);
		employees[2] = new Employee("Nayak", 3, 20000);
		
		for (Employee i : employees)
		{
			System.out.println(i.getName()+" "+i.getId() +" "+i.getB_salary());
		}
	}

}
