public class Student
{
	private int rollno, std, total;
	float perc;
	private String name;
	private int [] marks;
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public int getStd() {
		return std;
	}
	public void setStd(int std) {
		this.std = std;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int[] getMarks() {
		return marks;
	}
	public void setMarks(int[] marks) {
		this.marks = marks;
	}
	public void settotal(int total)
	{
		this.total = total;
	}
	public int gettotal()
	{
		return total;
	}
	public void setperc(float perc)
	{
		this.perc = perc;
	}
	public Student()
	{
		this.marks = new int[5];
	}
	
	public Student(int rollno, int std, String name, int[] marks)
	{
		this.marks = new int[5];
		this.rollno = rollno;
		this.std = std;
		this.name = name;
		this.marks = marks;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return (" "+name+" "+rollno);
	}
	
}