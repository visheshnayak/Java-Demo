
public class DemoObject 
{
	public static void main(String [] args)
	{
		Person person = new Person("PQR");
		Person peson2 = new Person("PQR");
		System.out.println(person);
		
		if(person.equals(peson2))
		{
			System.out.println("Equal");
		}
		else
		{
			System.out.println("Unequal");
		}
	}

}
