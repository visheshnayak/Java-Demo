
public interface Cable {
	void print();

}

class Train implements Cable {
	public void print() {

	}
}

class Demo {
	void display() {
		Cable cable = new Cable() {
			public void print() {
				System.out.println("Printing");
			}
		};
		cable.print();
	}

	public static void main(String[] args) {
		Demo demo = new Demo();
		demo.display();
//		show();
	}
	
	void show()
	{
		Cable c  = (abc) -> { System.out.println(abc.toString());};
		c.print();
	}
}

