
public class Emp extends Person 
{
	private int empId, sal;
	
	public Emp()
	{
		
	}
	
	public Emp(int empId, int sal, String name)
	{
		super(name);
		this.empId = empId;
		this.sal = sal;
	}
	
	public void show()
	{
		System.out.println(empId+" "+sal+" "+getName());
	}

}
