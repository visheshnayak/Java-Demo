
public class TestStudent {

	public static void main(String[] args)
	{
		Student s1, s2;
		s1 = new Student();
		s2 = new Student(1, "Vishesh", 20, 20, 20);
		s1.display();
		s2.display();
		
		s1.setRollno(5);
	}
}
