
public class TestEmp {
	
	public static void main(String [] args)
	{
		Employee emp1 = new Employee("A", 1, 10000);
		Employee emp2 = new Employee("B", 2, 15000);
		Employee emp3 = new Employee("C", 3, 20000);
		
		EmpMan em = new EmpMan();
		
		Employee e1 = em.showEmp(emp1);
		Employee e2 = em.showEmp(emp2);
		Employee e3 = em.showEmp(emp3);
		
		System.out.println(em.calcGS(e1)+" "+em.calcGS(e2)+" "+em.calcGS(e3));
		
	}

}
