package com.nseit.pojo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DemoDeSerializable {
	public static void main(String[] args)
	{
		FileInputStream fi = null;
		ObjectInputStream is = null;
		
		try {
			fi = new FileInputStream("company.txt");
			is = new ObjectInputStream(fi);
			Object o = is.readObject();
			Company company = (Company) o;
			System.out.println(company);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				fi.close();
				is.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		

	}

}
