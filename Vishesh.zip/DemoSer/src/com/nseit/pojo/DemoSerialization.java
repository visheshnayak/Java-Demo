package com.nseit.pojo;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class DemoSerialization {

	public static void main(String[] args) {
		// TODO Auto-generated method stub\
		try {
			FileOutputStream fo = new FileOutputStream("company.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fo);
			oos.writeObject(new Company("NSEit", "Mumbai", 1));
			oos.close();
		}catch (FileNotFoundException fe)
		{
			fe.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
