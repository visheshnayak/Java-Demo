package com.nseit.pojo;

import java.io.Serializable;

public class Company implements Serializable 
{
	private String name, address;
	private long cid;
	
	public Company()
	{
		this.name = "abc";
		this.address = "Andheri";
		this.cid = 1200L;
		
	}
	
	public Company(String name, String address, long cid)
	{
		this.name = name;
		this.address = address;
		this.cid = cid;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name+" "+cid+" "+address;
	}

}
