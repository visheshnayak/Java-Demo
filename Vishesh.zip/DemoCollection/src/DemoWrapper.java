

public class DemoWrapper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer data = 10;
		int x = 20;
		x = data;
		
		

	}

}
