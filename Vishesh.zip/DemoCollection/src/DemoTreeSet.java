import java.util.Set;
import java.util.TreeSet;
import com.pojo.*;

public class DemoTreeSet {
	public static void main(String [] args)
	{
		Set<Person> set = new TreeSet<Person>();
		
//		set.add(new Person());
		set.add(new Person("A", 16, 1));
		set.add(new Person("B", 15, 2));
//		set.add(new Person());
		
		System.out.println(set.size()+" "+set);
		
		Set<Person> set1 = new TreeSet<Person> ();
		
	}

}
