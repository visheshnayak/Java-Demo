import java.util.ArrayList;
import java.util.List;

public class DemoArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List list = new ArrayList();
		list.add(20);
		list.add("test");
		System.out.println(list);
		list.add("Wow");
		System.out.println(list);
		list.remove(1);
		System.out.println(list);
		list.set(0, 5);
		System.out.println(list);

	}

}
