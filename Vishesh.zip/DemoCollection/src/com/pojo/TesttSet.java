package com.pojo;

import java.util.HashSet;
import java.util.Set;

public class TesttSet {
	public static void main(String[] args)
	{
		Set<Person> set = new HashSet<>();
		
		set.add(new Person());
		set.add(new Person("A", 15, 1));
		set.add(new Person());
		System.out.println(set.size()+" "+set);
		
	}

}
