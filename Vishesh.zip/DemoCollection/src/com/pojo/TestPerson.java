package com.pojo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TestPerson {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Person> list = new ArrayList<Person>();
		list.add(new Person("A", 15, 1));
		list.add(new Person("B", 16, 2));
		System.out.println(list);

		Iterator<Person> iter = list.iterator();
		while(iter.hasNext())
			System.out.println(iter.next());
		
		System.out.println( ( list.indexOf(new Person("C", 17, 3)) == -1 ) ? "not found" : "found" );
		
		list.remove(new Person("B", 16, 2));
		System.out.println(list);
		
	}

}
