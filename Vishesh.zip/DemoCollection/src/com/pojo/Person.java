package com.pojo;

public class Person implements Comparable 
{
	private String name;
	private int age;
	private int adh_num;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getAdh_num() {
		return adh_num;
	}
	public void setAdh_num(int adh_num) {
		this.adh_num = adh_num;
	}
	public Person(String name, int age, int adh_num) {
		super();
		this.name = name;
		this.age = age;
		this.adh_num = adh_num;
	}
	public Person()
	{
		this.name = "None";
		this.age = 0;
		this.adh_num = 0;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Name: "+name+" Age: "+age+" Adhaar: "+adh_num;
	}
	@Override
	public boolean equals(Object arg0) {
		// TODO Auto-generated method stub
		return this.getAdh_num() == ((Person)arg0).getAdh_num();
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 1;
	}
	@Override
	public int compareTo(Object obj) {
		// TODO Auto-generated method stub
		Person person = (Person) obj;
//		return this.adh_num - person.adh_num;
		return this.name.compareTo(person.name);
	}

}
