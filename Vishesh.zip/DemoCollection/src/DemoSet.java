import java.util.HashSet;
import java.util.Set;

public class DemoSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Integer> set = new HashSet<>();
		
		set.add(10);
		set.add(05);
		set.add(100);
		set.add(10);
		
		System.out.println(set.size());
		System.out.println(set);
		
		set.remove(1);
		System.out.println(set.size());
		System.out.println(set);

	}

}
