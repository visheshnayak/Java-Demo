import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.pojo.Person;

public class DemoHashMap {
	public static void main(String[] args)
	{
		
		Map<String, Person> map = new HashMap<>();
		
		map.put("A", new Person());
		map.put("B", new Person ("NSE IT", 20, 123));
		map.put("C", new Person ("ABC", 20, 124));
		map.put("A",  new Person ("asdf", 25, 654));
		Set<Entry<String, Person>> set = map.entrySet();
		
		Iterator<Entry<String, Person>> iter = set.iterator();
		while(iter.hasNext())
		{
			Entry<String, Person> entry = iter.next();
			System.out.println(entry.getKey()+" "+entry.getValue());
			
		}
		
	}
}
