package com.nseit.exceptions;

public class OutofRangeException extends Exception {
	
	public OutofRangeException()
	{
		super("sorry");
	}
	
	public OutofRangeException(String message)
	{
		super(message);
	}
	
	public void show_message()
	{
		System.out.println(getMessage());
	}

}
