package com.nseit.exceptions;

public class TestException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 20;
		
		try {
			if(num <= 1 || num >=10)
			{
				throw new OutofRangeException("Nigga");
			}
		} catch (OutofRangeException e) {
			// TODO Auto-generated catch block
//			e.show_message();
			e.printStackTrace();
		}

	}

}
