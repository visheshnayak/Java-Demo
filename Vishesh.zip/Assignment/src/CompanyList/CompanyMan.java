package CompanyList;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class CompanyMan implements CompanyDAO
{
	/**
	 * 
	 */
	

	@Override
	public void addCompany(Company[] company) {
		// TODO Auto-generated method stub
		
		FileOutputStream fo = null;
		ObjectOutputStream oo = null;
		
		try {
			fo = new FileOutputStream("company.txt");
			oo = new ObjectOutputStream(fo);
			oo.writeObject(company);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				oo.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
	}
	
	@Override
	public Company[] showCompany() {
		// TODO Auto-generated method stub
		
		FileInputStream fi = null;
		ObjectInputStream oi = null;
		
		Company comp = null;
		Company[] res = new Company[5];
		
		int i = 0;
		
		try {
			fi = new FileInputStream("company.txt");
			oi = new ObjectInputStream(fi);
			
			Object o = oi.readObject();
			res = (Company[]) o;
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				fi.close();
				oi.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return res;
	}
}