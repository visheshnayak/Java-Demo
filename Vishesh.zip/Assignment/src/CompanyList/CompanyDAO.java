package CompanyList;

public interface CompanyDAO {
	public void addCompany(Company[] company);
	public Company[] showCompany();	

}


