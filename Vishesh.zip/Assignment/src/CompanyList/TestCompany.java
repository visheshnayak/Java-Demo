package CompanyList;

import java.util.Scanner;

public class TestCompany {
	
	public static void main(String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String name, address;
		
		Company input[] = new Company[5];
		
		for(int i=0 ; i< 5; i++)
		{
			input[i] = new Company();
		}
		
		System.out.println("Input");
		
		for (int i = 0; i<5; i++)
		{
			name = sc.nextLine();
			address = sc.nextLine();
			
			input[i] = new Company(name, address);
		}
		
		CompanyMan cm = new CompanyMan();
		cm.addCompany(input);
		Company[] disp = cm.showCompany();
		for (Company co: disp)
		{
			System.out.println(co);
		}
	}

}
