
public class DemoStatic {
	private int data;
	private static int count;
	
	public DemoStatic()
	{
		data = 10;
		count++;
	}
	
	static
	{
		count = 0;
	}
	 
	public void display()
	{
		System.out.println(data+" "+count);
	}
	
	public static void showCount()
	{
		System.out.println("Count: "+count );
	}
	
	public static void main(String []args)
	{
		if (count<10)
		{
			System.out.println(count);
			count++;
			main(args);
		}
		else
		{
			System.out.println("End");
		}
	}
}

