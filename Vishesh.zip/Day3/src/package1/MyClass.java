package package1;

public class MyClass {
	
	protected int add(int a, int b)
	{
		return a+b;
	}
	
	public void testAdd()
	{
		add(5, 6);
	}

}
