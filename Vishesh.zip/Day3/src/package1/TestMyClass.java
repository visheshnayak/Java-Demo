package package1;

public class TestMyClass {
	public void testClass()
	{
		new MyClass().add(5, 6);
	}

}
