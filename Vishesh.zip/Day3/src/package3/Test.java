package package3;

import package1.MyClass;

public class Test {
	
	public void test()
	{
		MyClass m = new MyClass();
	}

}
