package package2;

public class MyClass {
	void sub()
	{
		
	}

}
