import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DemoPreparedStatement {
	public static void main(String[] args)
	{
		Connection connection = MyConnection.setConnection();
		System.out.println("Connected");
		String sql = "INSERT INTO person VALUES(?,?,?)";
		
		try {
			PreparedStatement ps = connection.prepareStatement(sql);
		
			Scanner sc = new Scanner(System.in);
			Integer adh = sc.nextInt();
			String name = sc.next();
			Integer age = sc.nextInt();
			
			System.out.println("Input: ");
			ps.setInt(1, adh);
			ps.setString(2, name);
			ps.setInt(3, age);
			
			int rows = ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		MyConnection.closeConnection();
	}

}
