import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DemoConnectionsDAO {
	
	public void sql_insert(int rollno, String name, int marks_total, String address)
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl",
					"scott", "tiger");
			Statement statement = conn.createStatement();
			
			String sql = "INSERT INTO student VALUES("+rollno+",'"+name+","+marks_total+",'"+address+"')";
			int rows = statement.executeUpdate(sql);
			if(rows>0)
			{
				System.out.println("Data Inserted");
			}
			conn.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void sql_update(int qroll, String ch_address)
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl",
					"scott", "tiger");
			Statement statement = conn.createStatement();
			
			String sql = "UPDATE student SET address as "+ch_address+" WHERE rollno="+qroll;
			int rows = statement.executeUpdate(sql);
			if(rows>0)
			{
				System.out.println("Data Inserted");
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void sql_delete(int rollno)
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl",
					"scott", "tiger");
			Statement statement = conn.createStatement();
			
			String sql = "DELETE FROM student WHERE rollno="+rollno;
			int rows = statement.executeUpdate(sql);
			if(rows>0)
			{
				System.out.println("Data Inserted");
			}
			conn.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public List sql_display()
	{
		List res = new ArrayList<>();
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl",
					"scott", "tiger");
			Statement statement = conn.createStatement();
			String query = "SELECT * FROM student";
			ResultSet rs = statement.executeQuery(query);
			
			while (rs.next())
			{
				res.add(rs.getInt("rollno") + " " + rs.getString("name") + " " 
							+ rs.getInt("marks_total")+" "+rs.getString("address"));
			}
			conn.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return res;
	}

}
