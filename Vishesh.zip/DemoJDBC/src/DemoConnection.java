import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DemoConnection {
	public static void main(String [] args)
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl",
					"scott", "tiger");
			System.out.println("Connected");
			
//			Statement statement = conn.createStatement();
//			String sql = "INSERT INTO person VALUES(4,'PQR',12332)";
//			int rows = statement.executeUpdate(sql);
//			if(rows>0)
//			{
//				System.out.println("Data Inserted");
//			}
			
			Statement statement = conn.createStatement();
			String query = "SELECT * FROM person";
			ResultSet rs = statement.executeQuery(query);
			
			while (rs.next())
			{
				System.out.println(rs.getInt("adh_no") + " " + rs.getString("name") + " " 
							+ rs.getInt("age"));
			}
			conn.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
