import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DemoUpdate {
	public static void main(String [] args)
	{
		Connection conn = MyConnection.setConnection();
		String sql = "UPDATE person SET age=? WHERE adh_no=?";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Input: ");
			Integer adh = sc.nextInt();
			Integer age = sc.nextInt();
			
			ps.setInt(1, age);
			ps.setInt(2, adh);
			int rows = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		MyConnection.closeConnection();
	}

}
