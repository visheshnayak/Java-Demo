import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class DemoSearch_Prepared {
	public static void main(String[] args)
	{
		Connection connection = MyConnection.setConnection();
		String sql = "SELECT * FROM person WHERE adh_no=?";
		
		try {
			PreparedStatement ps = connection.prepareStatement(sql);
			Scanner sc = new Scanner (System.in);
			
			System.out.println("Input: ");
			Integer adh = sc.nextInt();
			
			ps.setInt(1, adh);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3));
			}
			sc.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		MyConnection.closeConnection();
	}

}
